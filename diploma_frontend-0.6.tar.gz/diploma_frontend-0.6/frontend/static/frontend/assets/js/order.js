var mix = {
    methods: {
        getOrder(orderId) {
            if(typeof orderId !== 'number') return
            this.getData(`/api/orders/${orderId}`)
                .then(data => {
                    this.orderId = data.id
                    this.createdAt = data.createdAt
                    this.fullName = data.fullName || this.fullName
                    this.phone = data.phone || this.phone
                    this.email = data.email || this.email
                    this.deliveryType = data.deliveryType || this.deliveryType
                    this.city = data.city || this.city
                    this.address = data.address || this.address
                    this.paymentType = data.paymentType || this.paymentType
                    this.status = data.status
                    this.totalCost = data.totalCost || '0.00'
                    this.products = data.products || []
                    console.log('Order data loaded:', data)
                    if (typeof data.paymentError !== 'undefined') {
                        this.paymentError = data.paymentError
                    }
                })
                .catch(error => {
                    console.error('Error loading order:', error)
                })
        },
        getProfile() {
            // Получаем данные профиля для заполнения формы
            this.getData('/api/profile')
                .then(data => {
                    // Заполняем только если поля пустые
                    if (!this.fullName) this.fullName = data.fullName || ''
                    if (!this.email) this.email = data.email || ''
                    if (!this.phone) this.phone = data.phone || ''
                    console.log('Profile data loaded:', data)
                })
                .catch(error => {
                    console.warn('Profile not loaded:', error)
                })
        },
        confirmOrder() {
            if (this.orderId !== null) {
                const orderData = {
                    fullName: this.fullName,
                    email: this.email,
                    phone: this.phone,
                    deliveryType: this.deliveryType,
                    paymentType: this.paymentType,
                    city: this.city,
                    address: this.address
                }
                
                this.postData(`/api/orders/${this.orderId}`, orderData)
                    .then(({ data }) => {
                        alert('Заказ подтвержден')
                        // Сохраняем orderId в sessionStorage для использования на странице оплаты
                        console.log('Saving orderId to sessionStorage:', this.orderId);
                        sessionStorage.setItem('currentOrderId', this.orderId.toString());
                        
                        // Проверяем что сохранилось корректно
                        const saved = sessionStorage.getItem('currentOrderId');
                        console.log('Verification - saved orderId:', saved);
                        
                        // Перенаправляем на соответствующую страницу оплаты в зависимости от выбранного типа
                        if (this.paymentType === 'someone') {
                            location.replace(`/payment-someone/`)
                        } else {
                            location.replace(`/payment/`)
                        }
                    })
                    .catch((error) => {
                        console.warn('Ошибка при подтверждении заказа:', error)
                        alert('Ошибка при подтверждении заказа')
                    })
            } else {
                console.error('Cannot confirm order: orderId is null');
                alert('Ошибка: ID заказа не определен');
            }
        },
        auth() {
            // Очищаем предыдущие ошибки
            this.clearFieldErrors()
            
            // Проверяем заполненность полей
            let hasError = false
            if (!this.loginData.username.trim()) {
                this.showFieldError('username', 'Введите логин')
                hasError = true
            }
            if (!this.loginData.password.trim()) {
                this.showFieldError('password', 'Введите пароль')
                hasError = true
            }
            
            if (hasError) return
            
            this.postData('/api/sign-in', JSON.stringify({ 
                username: this.loginData.username, 
                password: this.loginData.password 
            }))
                .then(({ data, status }) => {
                    location.assign(`/orders/${this.orderId}`)
                })
                .catch((error) => {
                    console.error('Auth error:', error)
                    if (error.response && error.response.data && error.response.data.error) {
                        const errorMessage = error.response.data.error
                        if (errorMessage.includes('credentials') || errorMessage.includes('Invalid')) {
                            this.showFieldError('password', 'Неверный логин или пароль')
                        } else {
                            alert(errorMessage)
                        }
                    } else {
                        this.showFieldError('password', 'Ошибка авторизации')
                    }
                })
        },
        register() {
            if (!this.showRegisterFields) {
                this.showRegisterFields = true
                return
            }
            
            // Очищаем предыдущие ошибки
            this.clearFieldErrors()
            
            // Проверяем заполненность полей
            let hasError = false
            if (!this.loginData.username.trim()) {
                this.showFieldError('username', 'Это поле обязательно для заполнения')
                hasError = true
            }
            if (!this.loginData.password.trim()) {
                this.showFieldError('password', 'Это поле обязательно для заполнения')
                hasError = true
            }
            if (!this.registerData.fullName.trim()) {
                this.showFieldError('fullName', 'Это поле обязательно для заполнения')
                hasError = true
            }
            if (!this.registerData.email.trim()) {
                this.showFieldError('email', 'Это поле обязательно для заполнения')
                hasError = true
            }
            
            if (hasError) return
            
            const regData = {
                username: this.loginData.username,
                password: this.loginData.password,
                name: this.registerData.fullName,
                email: this.registerData.email,
                phone: this.registerData.phone
            }
            
            this.postData('/api/sign-up', regData)
                .then(() => {
                    location.assign(`/orders/${this.orderId}`)
                })
                .catch((error) => {
                    console.error('Registration error:', error)
                    if (error.response && error.response.data && error.response.data.error) {
                        const errorMessage = error.response.data.error
                        
                        // Определяем какое поле вызвало ошибку
                        if (errorMessage.includes('username') || errorMessage.includes('именем')) {
                            this.showFieldError('username', errorMessage)
                        } else if (errorMessage.includes('email')) {
                            this.showFieldError('email', errorMessage)
                        } else if (errorMessage.includes('телефон')) {
                            this.showFieldError('phone', errorMessage)
                        } else {
                            alert(errorMessage)
                        }
                    } else {
                        alert('Ошибка регистрации')
                    }
                })
        },
        clearFieldErrors() {
            // Очищаем все ошибки полей
            $('.form-input').removeClass('form-input_error')
            $('.form-error').remove()
        },
        showFieldError(fieldId, message) {
            // Показываем ошибку для конкретного поля
            const field = $(`#${fieldId}`)
            if (field.length) {
                field.addClass('form-input_error')
                if (!field.next('.form-error').length) {
                    field.after(`<div class="form-error">${message}</div>`)
                }
            }
        },
        loadDeliverySettings() {
            this.getData('/api/delivery-settings/')
                .then(data => {
                    this.deliverySettings = data;
                })
                .catch(error => {
                    console.warn('Could not load delivery settings, using defaults:', error);
                });
        },
    },
    mounted() {
        if(location.pathname.startsWith('/orders/')) {
            const orderId = location.pathname.replace('/orders/', '').replace('/', '')
            this.orderId = orderId.length ? Number(orderId) : null
            
            // Сначала загружаем данные профиля для авторизованных пользователей
            this.getProfile()
            
            // Загружаем настройки доставки
            this.loadDeliverySettings()
            
            // Затем загружаем данные заказа, которые могут перезаписать некоторые поля
            if (this.orderId) {
                setTimeout(() => {
                    this.getOrder(this.orderId)
                }, 100) // Небольшая задержка чтобы профиль загрузился первым
            }
        }
    },
    data() {
        return {
            orderId: null,
            createdAt: null,
            fullName: '',
            phone: '',
            email: '',
            deliveryType: 'ordinary',
            city: '',
            address: '',
            paymentType: 'online',
            status: null,
            totalCost: '0.00',
            products: [],
            paymentError: null,
            deliverySettings: {
                express_delivery_cost: 500,
                free_delivery_threshold: 2000,
                regular_delivery_cost: 200
            },
            showRegisterFields: false,
            loginData: {
                username: '',
                password: ''
            },
            registerData: {
                fullName: '',
                email: '',
                phone: ''
            }
        }
    },
    computed: {
        productsCost() {
            if (!this.products || this.products.length === 0) {
                return 0;
            }
            const cost = this.products.reduce((total, item) => {
                const price = parseFloat(item.price) || 0;
                const count = parseInt(item.count) || 0;
                return total + (price * count);
            }, 0);
            return cost;
        },
        deliveryCost() {
            if (this.deliveryType === 'express') {
                return parseFloat(this.deliverySettings.express_delivery_cost) || 500;
            } else if (this.deliveryType === 'ordinary') {
                const productsCost = this.productsCost;
                const threshold = parseFloat(this.deliverySettings.free_delivery_threshold) || 2000;
                if (productsCost < threshold) {
                    return parseFloat(this.deliverySettings.regular_delivery_cost) || 200;
                } else {
                    return 0;
                }
            }
            return 0;
        },
        totalCostWithDelivery() {
            return this.productsCost + this.deliveryCost;
        },
        deliveryTypeName() {
            return this.deliveryType === 'express' ? 'Экспресс-доставка' : 'Обычная доставка';
        }
    },
} 