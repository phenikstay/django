var mix = {
	methods: {
		formatDate(dateStr) {
			if (!dateStr) return '';
			
			const date = new Date(dateStr);
			const day = date.getDate().toString().padStart(2, '0');
			const month = (date.getMonth() + 1).toString().padStart(2, '0');
			const year = date.getFullYear();
			const hours = date.getHours().toString().padStart(2, '0');
			const minutes = date.getMinutes().toString().padStart(2, '0');
			
			return `${day}.${month}.${year} ${hours}:${minutes}`;
		},
		getHistoryOrder() {
			this.getData("/api/orders")
				.then(data => {
					console.log(data)
					this.orders = data
				}).catch(() => {
				this.orders = []
				console.warn('Ошибка при получении списка заказов')
			})
		},
		getStatusText(status) {
			// Получаем текст статуса заказа
			const statusMap = {
				'pending': 'Ожидает обработки',
				'processing': 'Обрабатывается',
				'accepted': 'Принят',
				'completed': 'Выполнен',
				'canceled': 'Отменён'
			};
			return statusMap[status] || 'Неизвестно';
		}
	},
	mounted() {
		this.getHistoryOrder();
	},
	data() {
		return {
			orders: [],
		}
	}
}