var mix = {
    computed: {
      tags () {
          if(!this.product?.tags) return []
          return this.product.tags
      }
    },
    methods: {
        changeCount (value) {
            this.count = this.count + value
            if (this.count < 1) this.count = 1
        },
        getProduct() {
            const productId = location.pathname.startsWith('/product/')
            ? Number(location.pathname.replace('/product/', '').replace('/', ''))
            : null
            this.getData(`/api/product/${productId}`).then(data => {
                this.product = {
                    ...this.product,
                    ...data
                }
                if(data.images.length)
                    this.activePhoto = 0
            }).catch(() => {
                this.product = {}
                console.warn('Ошибка при получении товара')
            })
        },
        getProfile() {
            // Получаем данные профиля авторизованного пользователя для автозаполнения формы отзыва
            this.getData('/api/profile')
                .then(data => {
                    // Подставляем данные пользователя в форму отзыва
                    this.review.author = data.fullName || ''
                    this.review.email = data.email || ''
                    this.isAuthenticated = true;
                    this.profileLoaded = true;
                    console.log('Profile data loaded for review form:', data)
                })
                .catch(error => {
                    console.warn('Profile not loaded (user not authenticated):', error)
                    this.isAuthenticated = false;
                    this.profileLoaded = true;
                })
        },
        submitReview () {
            // Проверяем авторизацию
            if (!this.isAuthenticated) {
                alert('Необходимо авторизоваться для оставления отзыва');
                return;
            }
            
            // Дополнительная валидация перед отправкой
            if (!this.review.author || !this.review.email || !this.review.text) {
                alert('Пожалуйста, заполните все поля отзыва');
                return;
            }
            
            this.postData(`/api/product/${this.product.id}/review`, {
                author: this.review.author,
                email: this.review.email,
                text: this.review.text,
                rate: this.review.rate
            }).then(({data}) => {
                this.product.reviews = data
                alert('Отзыв опубликован')
                // Очищаем только текст отзыва и сбрасываем оценку, данные пользователя оставляем
                this.review.text = ''
                this.review.rate = 5
            }).catch(() => {
                console.warn('Ошибка при публикации отзыва')
                alert('Ошибка при публикации отзыва')
            })
        },
        setActivePhoto(index) {
            this.activePhoto = index
        }
    },
    mounted () {
        this.getProduct();
        // Загружаем данные профиля для автозаполнения формы отзыва
        this.getProfile();
    },
    data() {
        return {
            product : {},
            activePhoto: 0,
            count: 1,
            isAuthenticated: false,
            profileLoaded: false,
            review: {
                author: '',
                email: '',
                text: '',
                rate: 5
            }
        }
    },
}