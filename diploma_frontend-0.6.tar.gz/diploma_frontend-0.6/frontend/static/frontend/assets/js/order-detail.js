var mix = {
	methods: {
		getOrder(orderId) {
			if(typeof orderId !== 'number') return
			this.getData(`/api/orders/${orderId}/`)
				.then(data => {
					this.orderId = data.id
					this.createdAt = data.createdAt
					this.fullName = data.fullName
					this.phone = data.phone
					this.email = data.email
					this.deliveryType = data.deliveryType
					this.city = data.city
					this.address = data.address
					this.paymentType = data.paymentType
					this.status = data.status
					this.totalCost = data.totalCost
					this.products = data.products
					console.log(this.products)
					if (typeof data.paymentError !== 'undefined') {
						this.paymentError = data.paymentError
					}
				}).catch(error => {
					console.error('Ошибка загрузки заказа:', error);
				})
		},
		confirmOrder() {
			if (this.orderId !== null) {
				this.postData(`/api/orders/${this.orderId}/`, { ...this })
					.then(({ data }) => {
						alert('Заказ подтвержден')
						// Сохраняем orderId в sessionStorage для использования на странице оплаты
						sessionStorage.setItem('currentOrderId', this.orderId);
						
						// Перенаправляем на соответствующую страницу оплаты в зависимости от выбранного типа
						if (this.paymentType === 'someone') {
							location.replace(`/payment-someone/`)
						} else {
							location.replace(`/payment/`)
						}
					})
					.catch(() => {
						console.warn('Ошибка при подтверждения заказа')
					})
			}
		},
		auth() {
			const username = document.querySelector('#username').value
			const password = document.querySelector('#password').value
			this.postData('/api/sign-in', JSON.stringify({ username, password }))
				.then(({ data, status }) => {
					location.assign(`/orders/${this.orderId}`)
				})
				.catch(() => {
					alert('Ошибка авторизации')
				})
		},
		getStatusText(status) {
			// Получаем текст статуса заказа
			const statusMap = {
				'pending': 'Ожидает обработки',
				'processing': 'Обрабатывается',
				'accepted': 'Принят',
				'completed': 'Выполнен',
				'canceled': 'Отменён'
			};
			return statusMap[status] || 'Неизвестно';
		}
	},
	mounted() {
		let orderId = null;
		
		// Проверяем разные варианты URL
		if(location.pathname.startsWith('/order-detail/')) {
			orderId = location.pathname.replace('/order-detail/', '').replace('/', '')
		} else if(location.pathname.startsWith('/orders/')) {
			orderId = location.pathname.replace('/orders/', '').replace('/', '')
		}
		
		this.orderId = orderId && orderId.length ? Number(orderId) : null
		console.log('Order ID from URL:', this.orderId);
		
		if (this.orderId) {
			this.getOrder(this.orderId);
		}
	},
	data() {
		return {
			orderId: null,
			createdAt: null,
			fullName: null,
			phone: null,
			email: null,
			deliveryType: null,
			city: null,
			address: null,
			paymentType: null,
			status: null,
			totalCost: null,
			products: [],
			paymentError: null,
		}
	},
}