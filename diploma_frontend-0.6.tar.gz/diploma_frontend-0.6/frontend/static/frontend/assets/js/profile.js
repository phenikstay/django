var mix = {
    methods: {
        getProfile() {
            this.getData(`/api/profile`).then(data => {
                this.fullName = data.fullName
                this.avatar = data.avatar
                this.phone = data.phone
                this.email = data.email
            }).catch(() => {
                console.warn('Ошибка при получении профиля')
            })
        },
        getLastOrder() {
            this.getData(`/api/orders/last/`).then(data => {
                this.lastOrder = data.order
            }).catch(() => {
                console.warn('Ошибка при получении последнего заказа')
                this.lastOrder = null
            })
        },
        clearFieldErrors() {
            // Очищаем все ошибки полей
            $('.form-input').removeClass('form-input_error');
            $('.form-error').remove();
        },
        showFieldError(fieldId, message) {
            // Показываем ошибку для конкретного поля
            const field = $(`#${fieldId}`);
            if (field.length) {
                field.addClass('form-input_error');
                if (!field.next('.form-error').length) {
                    field.after(`<div class="form-error">${message}</div>`);
                }
            }
        },
        showSuccessMessage(message) {
            // Показываем сообщение об успехе
            alert(message);
        },
        changeProfile () {
            // Очищаем предыдущие ошибки
            this.clearFieldErrors();

            // Проверяем заполненность полей
            let hasError = false;
            if(!this.fullName.trim().length) {
                this.showFieldError('name', 'Это поле обязательно для заполнения');
                hasError = true;
            }
            if(!this.phone.trim().length) {
                this.showFieldError('phone', 'Это поле обязательно для заполнения');
                hasError = true;
            }
            if(!this.email.trim().length) {
                this.showFieldError('mail', 'Это поле обязательно для заполнения');
                hasError = true;
            }

            if (hasError) return;

            this.postData('/api/profile', {
                fullName: this.fullName,
                avatar: this.avatar,
                phone: this.phone,
                email: this.email
            }).then(({data}) => {
                this.fullName = data.fullName
                this.avatar = data.avatar
                this.phone = data.phone
                this.email = data.email
                this.showSuccessMessage('Профиль успешно обновлён')
            }).catch((error) => {
                console.warn('Ошибка при обновлении профиля', error)
                if (error.response && error.response.data && error.response.data.error) {
                    const errorMessage = error.response.data.error;
                    
                    // Определяем какое поле вызвало ошибку
                    if (errorMessage.includes('email')) {
                        this.showFieldError('mail', errorMessage);
                    } else if (errorMessage.includes('телефон')) {
                        this.showFieldError('phone', errorMessage);
                    } else {
                        // Общая ошибка - показываем alert
                        alert(errorMessage);
                    }
                } else {
                    alert('Ошибка при обновлении профиля')
                }
            })
        },
        changePassword () {
            // Очищаем предыдущие ошибки для полей паролей
            $('#passwordCurrent, #password, #passwordReply').removeClass('form-input_error');
            $('#passwordCurrent, #password, #passwordReply').next('.form-error').remove();

            // Проверяем заполненность полей
            let hasError = false;
            if (!this.passwordCurrent.trim().length) {
                this.showFieldError('passwordCurrent', 'Введите текущий пароль');
                hasError = true;
            }
            if (!this.password.trim().length) {
                this.showFieldError('password', 'Введите новый пароль');
                hasError = true;
            }
            if (!this.passwordReply.trim().length) {
                this.showFieldError('passwordReply', 'Подтвердите новый пароль');
                hasError = true;
            }
            if (this.password !== this.passwordReply && this.password.trim() && this.passwordReply.trim()) {
                this.showFieldError('passwordReply', 'Пароли не совпадают');
                hasError = true;
            }

            if (hasError) return;

            console.log({ currentPassword: this.passwordCurrent, newPassword: this.password })
            this.postData('/api/profile/password', { currentPassword: this.passwordCurrent, newPassword: this.password })
              .then(({data}) => {
                   this.showSuccessMessage('Пароль успешно изменён')
                    this.passwordCurrent = ''
                    this.password = ''
                    this.passwordReply = ''
                }).catch((error) => {
                    console.warn('Ошибка при сохранении пароля', error)
                    if (error.response && error.response.data && error.response.data.error) {
                        const errorMessage = error.response.data.error;
                        // Ошибки пароля обычно связаны с текущим паролем
                        if (errorMessage.includes('Current password')) {
                            this.showFieldError('passwordCurrent', 'Неверный текущий пароль');
                        } else {
                            alert(errorMessage);
                        }
                    } else {
                        alert('Ошибка при сохранении пароля')
                    }
                })
        },
        setAvatar (event) {
            const target = event.target
            const file = target.files[0]
            if (!file) return

            // Очищаем предыдущие ошибки для аватара
            $('#avatar').removeClass('form-input_error');
            $('#avatar').next('.form-error').remove();

            // Проверяем размер файла (не более 2 МБ)
            const maxSize = 2 * 1024 * 1024; // 2 МБ в байтах
            if (file.size > maxSize) {
                this.showFieldError('avatar', 'Размер файла не должен превышать 2 МБ');
                target.value = ''; // Очищаем поле выбора файла
                return;
            }

            // Проверяем тип файла (только изображения)
            const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
            if (!allowedTypes.includes(file.type)) {
                this.showFieldError('avatar', 'Разрешены только изображения (JPEG, PNG, GIF, WebP)');
                target.value = ''; // Очищаем поле выбора файла
                return;
            }

            const formData = new FormData()
            formData.append('avatar', file)

            this.postData('/api/profile/avatar', formData, {'Content-Type': 'multipart/form-data'})
            .then(() => {
                this.getProfile()
                this.showSuccessMessage('Аватар успешно обновлён')
            }).catch((error) => {
                console.warn('Ошибка при обновлении изображения', error)
                if (error.response && error.response.data && error.response.data.error) {
                    this.showFieldError('avatar', error.response.data.error);
                } else {
                    this.showFieldError('avatar', 'Ошибка при обновлении изображения');
                }
            })
        },
        getCookie(name) {
            let cookieValue = null;
            if (document.cookie && document.cookie !== '') {
                const cookies = document.cookie.split(';');
                for (let i = 0; i < cookies.length; i++) {
                    const cookie = cookies[i].trim();
                    // Does this cookie string begin with the name we want?
                    if (cookie.substring(0, name.length + 1) === (name + '=')) {
                        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                        break;
                    }
                }
            }
            return cookieValue;
        },
        clearAvatar() {
            this.avatar = null
        },
        formatDate(dateString) {
            // Форматируем дату для отображения
            const date = new Date(dateString);
            return date.toLocaleDateString('ru-RU', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        },
        getStatusText(status) {
            // Получаем текст статуса заказа
            const statusMap = {
                'pending': 'Ожидает обработки',
                'processing': 'Обрабатывается',
                'accepted': 'Принят',
                'completed': 'Выполнен',
                'canceled': 'Отменён'
            };
            return statusMap[status] || 'Неизвестно';
        }
    },
    created() {
        this.getProfile();
        this.getLastOrder();
    },
    data() {
        return {
            fullName: null,
            phone: null,
            email: null,
            avatar: null,
            lastOrder: null,
            password: '',
            passwordCurrent: '',
            passwordReply: ''
        }
    },
}