var mix = {
	methods: {
		signUp() {
			console.log('SignUp called with data:', {
				name: this.name,
				username: this.username,
				email: this.email,
				phone: this.phone,
				password: this.password
			})
			
			// Простая проверка
			if (!this.name || !this.username || !this.password) {
				alert('Заполните обязательные поля: Имя, Логин, Пароль')
				return
			}
			
			this.postData('/api/sign-up', JSON.stringify({
				name: this.name,
				username: this.username,
				email: this.email || '',
				phone: this.phone || '',
				password: this.password
			}))
				.then(({ data, status }) => {
					console.log('Registration successful:', data)
					alert('Регистрация успешна!')
					location.assign(`/`)
				})
				.catch((error) => {
					console.error('Registration error details:', error)
					console.log('Error response:', error.response)
					
					if (error.response && error.response.data && error.response.data.error) {
						const errorMessage = error.response.data.error
						console.log('Error message:', errorMessage)
						
						// Очищаем старые ошибки
						this.clearFieldErrors()
						
						// Определяем какое поле вызвало ошибку и подсвечиваем его
						if (errorMessage.includes('username') || errorMessage.includes('именем')) {
							this.showFieldError('login', errorMessage)
						} else if (errorMessage.includes('email')) {
							this.showFieldError('email', errorMessage)
						} else if (errorMessage.includes('телефон')) {
							this.showFieldError('phone', errorMessage)
						} else {
							// Общая ошибка - показываем alert
							alert('Ошибка: ' + errorMessage)
						}
					} else {
						alert('Ошибка регистрации! Проверьте консоль для деталей.')
					}
				})
		},
		clearFieldErrors() {
			// Очищаем все ошибки полей
			const inputs = document.querySelectorAll('.user-input, input[type="password"]')
			inputs.forEach(input => {
				input.classList.remove('form-input_error', 'user-input_error')
			})
			const errors = document.querySelectorAll('.form-error')
			errors.forEach(error => error.remove())
		},
		showFieldError(fieldId, message) {
			// Показываем ошибку для конкретного поля
			const field = document.getElementById(fieldId)
			if (field) {
				if (field.classList.contains('user-input')) {
					field.classList.add('user-input_error')
				} else {
					field.classList.add('form-input_error')
				}
				// Удаляем старые ошибки для этого поля
				let existingError = field.nextElementSibling
				if (existingError && existingError.classList.contains('form-error')) {
					existingError.remove()
				}
				// Добавляем новую ошибку
				const errorDiv = document.createElement('div')
				errorDiv.className = 'form-error'
				errorDiv.style.color = '#dc3545'
				errorDiv.style.fontSize = '12px'
				errorDiv.style.marginTop = '5px'
				errorDiv.textContent = message
				field.parentNode.insertBefore(errorDiv, field.nextSibling)
			}
		}
	},
	mounted() {
		console.log('SignUp component mounted')
		console.log('Initial data:', this.$data)
	},
	data() {
		return {
			name: '',
			username: '',
			email: '',
			phone: '',
			password: ''
		}
	}
}