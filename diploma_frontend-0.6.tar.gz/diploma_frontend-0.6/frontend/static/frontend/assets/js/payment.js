var mix = {
	methods: {
		submitPayment() {
			// Валидация номера карты согласно ТЗ
			if (!this.validateCardNumber()) {
				alert('Номер карты должен быть четным числом не длиннее 8 цифр');
				return;
			}

			// Получаем orderId из sessionStorage (сохраненный в order.js)
			const orderIdStr = sessionStorage.getItem('currentOrderId');
			const orderId = orderIdStr ? parseInt(orderIdStr) : null;
			
			console.log('Retrieved orderId from sessionStorage:', {
				raw: orderIdStr,
				parsed: orderId,
				isValid: orderId && orderId > 0
			});
			
			if (!orderId || orderId <= 0) {
				alert('Ошибка: ID заказа не найден или некорректный');
				console.error('orderId не найден или некорректный:', orderId);
				return;
			}
			
			console.log('Отправляем данные карты для заказа:', orderId, {
				number: this.number1,
				name: this.name,
				year: this.year,
				month: this.month,
				code: this.code,
			})
			
			this.postData(`/api/payment/${orderId}/`, {
				name: this.name,
				number: this.number1,
				year: this.year,
				month: this.month,
				code: this.code
			}).then(() => {
				console.log('Оплата отправлена, переходим на страницу ожидания');
				this.number1 = ''
				this.name = ''
				this.year = ''
				this.month = ''
				this.code = ''
				location.assign('/progress-payment/')
			}).catch(() => {
			 	console.warn('Ошибка при оплате')
			 	alert('Ошибка при обработке платежа')
			})
		},
		
		validateCardNumber() {
			// Убираем все нецифровые символы
			const cleanNumber = this.number1.replace(/\D/g, '');
			
			// Проверяем длину (не более 8 цифр)
			if (cleanNumber.length === 0 || cleanNumber.length > 8) {
				return false;
			}
			
			// Проверяем на четность
			const number = parseInt(cleanNumber);
			if (number % 2 !== 0) {
				return false;
			}
			
			// Обновляем поле с очищенным номером
			this.number1 = cleanNumber;
			
			console.log('Валидация карты:', {
				исходный: this.number1,
				очищенный: cleanNumber,
				четный: number % 2 === 0,
				длина: cleanNumber.length
			});
			
			return true;
		}
	},
	data() {
		return {
			number1: '',
			month: '',
			year: '',
			name: '',
			code: ''
		}
	}
}